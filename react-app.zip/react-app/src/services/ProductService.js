const initProduct = [
    {
        id: 1,
        name: 'Moto G200',
        price: 7599,
        description: 'Teléfono Celular'
    },
    {
        id: 2,
        name: 'IPhone 13 Pro',
        price: 14999,
        description: 'Teléfono Celular'    
    },
    {
        id: 3,
        name: 'Galaxy S23',
        price: 17999,
        description: 'Teléfono Celular'
    }
];

export const listProduct = () => {
    return initProduct;
}