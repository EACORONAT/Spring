import { PropTypes } from "prop-types";

export const ProductDetail = ({ handlerSelectedProduct, handlerRemove, product = {} }) => {
    return (
        <tr>
            <td className="text-center">{product.name}</td>
            <td className="text-center">{product.description}</td>
            <td className="text-center">{product.price}</td>
            <td className="text-center">                
                <button className="btn btn-secondary w-80" onClick={() => handlerSelectedProduct(product)}>
                    Actualizar
                </button>
            </td>
            <td className="text-center">
                <button className="btn btn-danger w-80" onClick={() => handlerRemove(product.id)}>
                    Eliminar
                </button>
            </td>
        </tr>
    )
}

ProductDetail.propTypes = {
    product: PropTypes.object.isRequired,
    handlerRemove: PropTypes.func.isRequired,
    handlerSelectedProduct: PropTypes.func.isRequired
}