import { PropTypes } from "prop-types"
import { ProductDetail } from "./ProductDetail"

export const ProductGrid = ({ handlerSelectedProduct, handlerRemove, products = [] }) => {
    return (
        <table className="table table-hover table-striped">
            <thead>
                <tr>
                    <th className="text-center">Nombre</th>
                    <th className="text-center">Descripción</th>
                    <th className="text-center">Precio</th>
                    <th className="text-center" colSpan="2">Accion</th>
                </tr>
            </thead>
            <tbody>
                {products.map(product => {
                    return <ProductDetail handlerSelectedProduct={handlerSelectedProduct} handlerRemove={handlerRemove} product={product} key={product.name} />
                })}
            </tbody>
        </table>
    )
}

ProductGrid.propTypes = {
    products: PropTypes.array.isRequired,
    handlerRemove: PropTypes.func.isRequired,
    handlerSelectedProduct: PropTypes.func.isRequired
}