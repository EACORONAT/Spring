import axios from "axios";

const initProduct = [
    {
        id: 1,
        name: 'Moto G200',
        price: 7599,
        description: 'Teléfono Celular'
    },
    {
        id: 2,
        name: 'IPhone 13 Pro',
        price: 14999,
        description: 'Teléfono Celular'    
    },
    {
        id: 3,
        name: 'Galaxy S23',
        price: 17999,
        description: 'Teléfono Celular'
    }
];

const rutaBase = 'http://localhost:8080/products';

export const listProduct = () => {
    return initProduct;
}

export const findAll = async() => {
    try {
        const response = await axios.get(rutaBase);
        return response;    
    } catch (error) {
        console.log(error);
    }
    return null;
}

export const create = async ({name, description, price}) => {
    try {        
        const response = await axios.post(rutaBase,{
            name,
            description,
            price
        });
        return response;
    } catch (error) {
        console.log(error);
    }
    return undefined;
}

export const update = async ({id, name, description, price}) => {
    try {        
        const response = await axios.put(rutaBase + '/' + id,{
            name,
            description,
            price
        });
        return response;
    } catch (error) {
        console.log(error);
    }
    return undefined;
}

export const remove = async (id) => {
    try {
        await axios.delete(rutaBase + '/' + id);
    } catch (error) {
        console.log(error);
    }
}